package com.robosoft.HospitalManagementJdbc.service;

public interface WardServices {
}
